//
//  GameScene.swift
//  ScoopThePoop
//
//  Created by John Kennedy on 12/16/20.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    private var label : SKLabelNode?
    private var highLabel : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    private var poopBar : SKSpriteNode?
    private var gameOver : SKSpriteNode?
    private var messSplash : SKSpriteNode?
    private var helpSprite : SKSpriteNode?
    
    private var icon1 : SKSpriteNode?
    private var icon2 : SKSpriteNode?
    private var icon3 : SKSpriteNode?
    private var icon4 : SKSpriteNode?
    private var icon5 : SKSpriteNode?
    private var iconTalk : SKSpriteNode?
    private var iconWords : SKLabelNode?
    private var cat : SKSpriteNode?
    
    
    var leftScooper : SKSpriteNode?
    var rightScooper : SKSpriteNode?
    
    var pause = false
    
    var score = 0
    var highscore = 20
    var pooplevel = 0
    var Frequency_of_magic : CGFloat = 15
    var Frequency_of_mustard : CGFloat = 35
    var Speed_of_poops : CGFloat = -3
    var poopImpulse : CGFloat = -0.1
    
    var STARTX : CGFloat = 0
    var STARTY : CGFloat = 500
    
    enum gameStateType {
        case Welcome
        case ReadyToPlay
        case Playing
        case GameOver
    }
    
    var gameState : gameStateType = .Welcome
    var gameStateCounter = 0
    
    struct poopType : Equatable {
        var sprite: SKSpriteNode
        var active: Bool
        var type : Int
        var dx : CGFloat
        var dy : CGFloat
        var size : CGFloat
        var magic : Bool
        var poopswiped : Bool
        var mustard : Bool
    }
    // var animator: UIViewPropertyAnimator!
    
    var poopSprites :[poopType] = [poopType]()
    
    let angleUp = SKAction.rotate(toAngle: 0.2, duration: 0.1)
    let moveOut = SKAction.moveTo(x: -100, duration: 0.25)
    let angleDown = SKAction.rotate(toAngle: -0.2, duration: 0.1)
    let moveBack = SKAction.moveTo(x: -461.5, duration: 0.3)
    
    let moveOutR = SKAction.moveTo(x: 153, duration: 0.25)
    let moveBackR = SKAction.moveTo(x: 461.5, duration: 0.3)
    
    var scoopActionLeft : SKAction?
    var scoopActionRight : SKAction?
    var scoopActionLeftPart1 : SKAction?
    var scoopActionRightPart1 : SKAction?
    var scoopActionLeftPart2 : SKAction?
    var scoopActionRightPart2 : SKAction?
    var splashAction : SKAction?
    var talkAction : SKAction?
    var hidehelpAction : SKAction?
    
    
    var poopFrames : [SKTexture] = [SKTexture (imageNamed: "rainbow1-emoji"), SKTexture (imageNamed: "rainbow2-emoji"), SKTexture (imageNamed: "rainbow3-emoji"), SKTexture (imageNamed: "rainbow4-emoji"), SKTexture (imageNamed: "rainbow5-emoji"), SKTexture (imageNamed: "rainbow6-emoji"), SKTexture (imageNamed: "rainbow7-emoji")]
    
    var peekFrames : [SKTexture] = [SKTexture (imageNamed: "peek-left-poop-emoji"), SKTexture (imageNamed: "pink-poop-emoji"),SKTexture (imageNamed: "peek-right-poop-emoji"),SKTexture (imageNamed: "pink-poop-emoji")]
    
    var peekMustardFrames : [SKTexture] = [SKTexture (imageNamed: "mustard-peek-left-poop-emoji"), SKTexture (imageNamed: "mustard-poop-emoji"),SKTexture (imageNamed: "mustard-peek-right-poop-emoji"),SKTexture (imageNamed: "mustard-poop-emoji")]
    
    
    
    private var rainbowAnimation : SKAction?
    private var peekAnimation : SKAction?
    private var peekMustardAnimation : SKAction?
    
    
    func gameStateManager()
    {
        
        
        switch gameState
        {
        case .Welcome:
            
            if gameStateCounter == 0
            {
                
                //highLabel?.isHidden = true
                
            }
            
            gameStateCounter = gameStateCounter + 1
            
        case .ReadyToPlay:
            
            
            if gameStateCounter == 0
            {
                // self.helpSprite?.alpha = 0.0
                self.helpSprite?.run(hidehelpAction!)
                self.gameOver?.alpha = 0.0
                self.gameOver?.setScale(0.1)
                label?.text = "GET READY TO SCOOP!"
                highLabel?.isHidden = true
                score = 0
                pooplevel = 0
                poopBar?.isHidden = true
                poopBar?.xScale = 0.1
                resetAllPoop()
            }
            
            gameStateCounter = gameStateCounter + 1
            if (gameStateCounter > 60)
            {
                gameStateCounter = 0
                gameState = .Playing
            }
            
            
            
        case .Playing:
            
            if gameStateCounter == 0
            {
                label?.text = "SCORE: " + String(score)
                highLabel?.text = "HIGH: " + String(highscore)
                highLabel?.isHidden = false
            }
            
            gameStateCounter = gameStateCounter + 1
            
            
            switch score {
            
            case 10..<20: Speed_of_poops = -3.5; poopImpulse = -0.15
            case 20..<30: Speed_of_poops = -4.0; poopImpulse = -0.175
            case 30..<40: Speed_of_poops = -4.5; poopImpulse = -0.2
            case 40..<50: Speed_of_poops = -5.0; poopImpulse = -0.225
            case 50..<60: Speed_of_poops = -5.5; poopImpulse = -0.25
            case 60..<70: Speed_of_poops = -6.0; poopImpulse = -0.275
            case 70..<80: Speed_of_poops = -6.5; poopImpulse = -0.300
            case 80..<90: Speed_of_poops = -6.5; poopImpulse = -0.325
            case 90..<100: Speed_of_poops = -6.5; poopImpulse = -0.35
            case 100..<100: Speed_of_poops = -6.5; poopImpulse = -0.375
            case 110..<120: Speed_of_poops = -6.5; poopImpulse = -0.4
            case 120..<1000: Speed_of_poops = -6.5; poopImpulse = -0.5
            default: Speed_of_poops = -3.0; poopImpulse = -0.1
            }
            
            
            
        case .GameOver:
            
            if gameStateCounter == 0
            {
                let defaults = UserDefaults.standard
                defaults.set(highscore, forKey: "highscore")
                
                self.gameOver?.run(SKAction.fadeIn(withDuration: 0.3))
                self.gameOver?.run(SKAction.scale(to: 2.0, duration: 0.3))
                
            }
            
            gameStateCounter = gameStateCounter + 1
            if (gameStateCounter > 60)
            {
                gameStateCounter = 0
                gameState = .Welcome
            }
            
            
            
            
        }
    }
    
    /*
     func didBeginContact(contact: SKPhysicsContact) {
     
     
     let otherNode = contact.bodyA.node == ball.sprite ? contact.bodyB.node : contact.bodyA.node
     
     if let obstacle = otherNode as? Obstacle {
     ball.onCollision(obstacle)
     }
     else if let border = otherNode as? SKSpriteNode {
     
     assert(border.name == "border", "Bad assumption")
     
     let strength = 1.0 * (ball.sprite.position.x < frame.width / 2 ? 1 : -1)
     let body = ball.sprite.physicsBody!
     body.applyImpulse(CGVector(dx: strength, dy: 0))
     }
     
     }
     */
    
    func declareAllPoops()
    {
        for _ in 0...32
        {
            let sprite = SKSpriteNode(imageNamed: "pink-poop-emoji")
            self.addChild(sprite)
            sprite.isHidden = true
            
            let poop = poopType(sprite: sprite, active: false, type: 0, dx: 0.0, dy : 0.0, size: 16.0, magic: false, poopswiped: false, mustard: false)
            
            
            poop.sprite.physicsBody = SKPhysicsBody(circleOfRadius: 16)
            
            poop.sprite.physicsBody?.affectedByGravity = true
            poop.sprite.physicsBody?.isDynamic = true
            poop.sprite.physicsBody?.mass = 0.0010
            poop.sprite.physicsBody?.restitution = 0.8
            poop.sprite.physicsBody?.linearDamping = 0.0
            poop.sprite.physicsBody?.friction = 0.3
            
            
            poopSprites.append(poop)
        }
        
        poopBar =  SKSpriteNode(imageNamed: "poopBar")
        self.addChild(poopBar!)
        
    }
    
    func resetAllPoop()
    {
        for _ in 0...32
        {
            
            if let index = poopSprites.firstIndex(where: { $0.active == true})
            {
                poopSprites[index].active = false
                poopSprites[index].sprite.isHidden = true
                
            }
        }
        
    }
    
    func SaySomething( saying : Int)
    {
        var person = Int.random(in: 1...4)
        var phrase = Int.random(in: 1...40)
        
        
        if saying > 50
        {
            phrase = saying
            person = 5
        }
        
        
        
        switch person {
        case 1 : icon1?.alpha = 1; icon1?.run(talkAction!)
        case 2 : icon2?.alpha = 1;icon2?.run(talkAction!)
        case 3 : icon3?.alpha = 1;icon3?.run(talkAction!)
        case 4 : icon4?.alpha = 1;icon4?.run(talkAction!)
        case 5 : icon5?.alpha = 1;icon5?.run(talkAction!)
            
        default : icon4?.run(talkAction!)
        }
        
        
        switch phrase {
        case 1: iconWords?.text = "You are weak!"
        case 2: iconWords?.text = "Let's have a meeting!"
        case 3: iconWords?.text = "That's a lot of poop"
        case 4: iconWords?.text = "You're on mute!"
        case 5: iconWords?.text = "Sorry, my dog barfed"
        case 6: iconWords?.text = "(Insert meme here)"
        case 7: iconWords?.text = "Go sports!"
        case 8: iconWords?.text = "I had a buritto!"
        case 9: iconWords?.text = "Not the face!"
        case 10: iconWords?.text = "Make a GitIssue"
        case 11: iconWords?.text = "Is it Wednesday?"
        case 12: iconWords?.text = "It's beer o'clock"
        case 13: iconWords?.text = "Where's Eliot?"
        case 14: iconWords?.text = "Nap time"
        case 15: iconWords?.text = "Winners don't poop"
        case 16: iconWords?.text = "I miss the office"
        case 17: iconWords?.text = "Whiskey time"
        case 18: iconWords?.text = "Who invited them?"
        case 19: iconWords?.text = "I heart TEAMS"
        case 20: iconWords?.text = "Pants ON, please"
        case 21: iconWords?.text = "What does the B.I. say?"
        case 22: iconWords?.text = "There's poop on the dashboard"
        case 23: iconWords?.text = "Time for our 1:1"
        case 24: iconWords?.text = "Push that PR!"
        case 25: iconWords?.text = "All-you-can-eat salad"
        case 26: iconWords?.text = "That's Level 64 behavior"
        case 27: iconWords?.text = "Poop for everyone!"
        case 28: iconWords?.text = "Who blocked the toilet?"
        case 29: iconWords?.text = "I miss Doug"
        case 30: iconWords?.text = "Let's sing the poop song!"
            
        case 31: iconWords?.text = "It just hit the fan!"
        case 32: iconWords?.text = "It happens."
        case 33: iconWords?.text = "Building 25 smells of peas"
        case 34: iconWords?.text = "Now wash your hands"
        case 35: iconWords?.text = "Wear a mask"
        case 36: iconWords?.text = "Better poop than trump"
        case 37: iconWords?.text = "The elevator's broken"
        case 38: iconWords?.text = "More Talking Rain!"
        case 39: iconWords?.text = "Wait did you see that?"
        case 40: iconWords?.text = "That's Jeff's parking spot"
            
        case 41: iconWords?.text = "POOP - there it is"
            
            
        case 100: iconWords?.text = "First poop of the day!"
        case 200: iconWords?.text = "Don't scoop the rainbows!"
        case 300: iconWords?.text = "  One more poop & you're done!"
            
        default: iconWords?.text = ""
        }
        
        iconTalk?.alpha = 1
        iconWords?.alpha = 1
        
        iconWords?.run(talkAction!)
        iconTalk?.run(talkAction!)
        
    }
    
    
    func addNewPoop()
    {
        var magic = false
        var mustard = false
        
        if Int(CGFloat.random(in: 0..<Frequency_of_mustard)) == 1
        {
            mustard = true
        }
        else
        {
            if Int(CGFloat.random(in: 0..<Frequency_of_magic)) == 1
            {
                magic = true
            }
        }
        
        
        
        
        if let index = poopSprites.firstIndex(where: { $0.active == false})
        {
            let rx = CGFloat.random(in: -0.5 ..< 0.5)
            poopSprites[index].dx = rx
            poopSprites[index].sprite.position.x = STARTX + (rx*128)
            poopSprites[index].sprite.position.y = STARTY
            poopSprites[index].active = true
            poopSprites[index].sprite.isHidden = false
            poopSprites[index].sprite.size = CGSize(width: 32, height: 32)
            poopSprites[index].size = 32
            poopSprites[index].sprite.zPosition = 5.0
            poopSprites[index].sprite.zRotation = CGFloat.random(in: -0.2..<0.2)
            poopSprites[index].dy = Speed_of_poops
            poopSprites[index].dx = CGFloat.random(in: -1..<1)
            poopSprites[index].magic = magic
            poopSprites[index].mustard = mustard
            poopSprites[index].poopswiped = false
            poopSprites[index].sprite.physicsBody?.velocity = CGVector(dx: 0.0, dy: 0.0)
            poopSprites[index].sprite.physicsBody?.angularVelocity = 0.0
            
            poopSprites[index].sprite.physicsBody?.applyImpulse(CGVector(dx: rx * 5, dy: 5*poopImpulse))
            
            
            
            
            
            if (magic)
            {
                poopSprites[index].sprite.run(rainbowAnimation!)
            }
            
            else
            {
                if (mustard)
                {
                    poopSprites[index].sprite.run(peekMustardAnimation!)
                }
                else
                {
                    poopSprites[index].sprite.run(peekAnimation!)
                }
            }
        }
        else
        {
            print("All pooped out")
        }
        
    }
    
    
    func movePoops()
    {
        var removeIndex : Int = -1
        var swipe = false
        var update = false
        
        
        for poop in poopSprites
        {
            if poop.active
            {
                var x = poop.sprite.position.x
                var y = poop.sprite.position.y
                var h = poop.sprite.size.height
                
                h = (STARTY - y) / 8
                
                
                y = y + poop.dy
                x = x + poop.dx
                
                
                //   poop.sprite.position = CGPoint(x: x, y: y)
                poop.sprite.size = CGSize(width: h, height: h)
                
                let rx = rightScooper?.position.x
                let ry = rightScooper?.position.y
                
                let lx = leftScooper?.position.x
                let ly = leftScooper?.position.y
                
                
                if close(test: (rx! - x), target: 211 ) && close(test: (ry! - y ), target: -26) && rightScooper!.zRotation > 0 && ((rightScooper?.action(forKey: "scoopingRight")) != nil)
                {
                    
                    if let removeIndex = poopSprites.firstIndex(of : poop)
                    {
                        //removeIndex = poopSprites.firstIndex(of : poop)!
                        poopSprites[removeIndex].dx = 20
                        poopSprites[removeIndex].dy = -5
                        
                        poopSprites[removeIndex].sprite.physicsBody?.applyImpulse(CGVector(dx: 1, dy: 0))
                        
                        swipe = true
                        poopSprites[removeIndex].poopswiped = true
                        update = true
                    }
                }
                
                
                if close(test: (lx! - x), target: -223 ) && close(test: (ly! - y ), target: -16) && leftScooper!.zRotation < 0 && ((leftScooper?.action(forKey: "scoopingLeft")) != nil)
                {
                    if let removeIndex = poopSprites.firstIndex(of : poop)
                    {
                        //removeIndex = poopSprites.firstIndex(of : poop)!
                        poopSprites[removeIndex].sprite.physicsBody?.applyImpulse(CGVector(dx: -1, dy: 0))
                        
                        poopSprites[removeIndex].dx = -20
                        poopSprites[removeIndex].dy = -5
                        poopSprites[removeIndex].poopswiped = true
                        update = true
                        swipe = true
                    }
                }
                
                
                
                // Off the bottom which is how all poops end up. //a BAD THING unless it's magic
                if y < -500 && poop.active
                {
                    if poop.poopswiped
                    {
                        
                        if poop.magic
                        {
                            // Aww, missed out
                            SaySomething(saying: 200)
                            
                        }
                        else
                        {
                            if poop.mustard
                            {
                                score = score + 3
                            }
                            else
                            {
                                score = score + 1
                            }
                                
                            if (score==1)
                            {
                                SaySomething(saying: 100)
                            }
                            
                            if fmod(Double(score),5)==0
                            {
                                SaySomething(saying: 0)
                            }
                        }
                    }
                    else
                    
                    {
                        
                        if poop.magic
                        {
                            pooplevel = pooplevel - 2
                            
                            let newSplat = SKEmitterNode(fileNamed: "Rainbows.sks")
                            self.addChild(newSplat!)
                            newSplat?.position = CGPoint(x: 0, y: 0)
                            newSplat?.run(SKAction.sequence([SKAction.wait(forDuration: 0.75), SKAction.removeFromParent()]))
                            
                            cat?.run(SKAction.sequence([SKAction.moveTo(x: -370, duration: 0.4), SKAction.wait(forDuration: 0.5), SKAction.moveTo(x: -600, duration: 0.4)]))
                            
                            
                            if pooplevel < 0
                            {
                                pooplevel = 0
                            }
                        }
                        else
                        {
                            //self.splat?.particleBirthRate = 500
                            //self.splat?.numParticlesToEmit = 100
                            //self.splat?.particleLifetime = 1
                            
                            // Create an instance of the splat and then remove it a second later
                            
                            
                            if poop.mustard
                            {
                                let newSplat = SKEmitterNode(fileNamed: "SplatMustardParticle.sks")
                                self.addChild(newSplat!)
                                newSplat?.position = CGPoint(x: poop.sprite.position.x, y: -512)
                                newSplat?.run(SKAction.sequence([SKAction.wait(forDuration: 0.5), SKAction.removeFromParent()]))
                                

                                pooplevel = pooplevel + 3
                            }
                            else
                            {
                                let newSplat = SKEmitterNode(fileNamed: "SplatParticle.sks")
                                self.addChild(newSplat!)
                                newSplat?.position = CGPoint(x: poop.sprite.position.x, y: -512)
                                newSplat?.run(SKAction.sequence([SKAction.wait(forDuration: 0.5), SKAction.removeFromParent()]))
                                
                                pooplevel = pooplevel + 1
                            }
                            
                           
                            
                            if pooplevel == 14
                            {
                                SaySomething(saying: 300)
                            }
                            
                        }
                    }
                    
                    
                    removeIndex = poopSprites.firstIndex(of : poop)!
                    
                    
                    
                    // Update Score and Pool Level
                    update = true
                }
            }
        }
        
        if removeIndex != -1 && swipe == false
        {
            poopSprites[removeIndex].active = false
            
            poopSprites[removeIndex].sprite.isHidden = true
        }
        
        if (update)
        {
            
            UpdateScorePoopLevel()
        }
        
    }
    
    
    func UpdateScorePoopLevel()
    {
        self.poopBar?.isHidden = false
        self.poopBar?.position = CGPoint(x: 0,y: -550)
        self.poopBar?.zPosition = 20
        
        if score > highscore
        {
            highscore = score
        }
        
        label?.text = "SCORE: " + String(score)
        highLabel?.text = "HIGH: " + String(highscore)
        
        if let pb = self.poopBar {
            pb.run(SKAction.scaleX(to: 0.2 * CGFloat(self.pooplevel), y: 1.0, duration: 1.0))
            
        }
        
        
        if pooplevel > 14
        {
            gameStateCounter = 0
            gameState = .GameOver
        }
    }
    
    func close(test : CGFloat, target : CGFloat) -> Bool
    {
        if abs(test - target) < 65
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    override func didMove(to view: SKView) {
        
        // This is the "view did appear"
        
        let defaults = UserDefaults.standard
        
        let hs = defaults.integer(forKey: "highscore")
        
        if hs == 0
        {
            highscore = 20
        }
        else
        {
            highscore = hs
        }
        
        
        
        leftScooper = self.childNode(withName: "scoopLeft") as? SKSpriteNode
        rightScooper = self.childNode(withName: "scoopRight") as? SKSpriteNode
        
        
        rainbowAnimation = SKAction.repeatForever(SKAction.animate(with: poopFrames, timePerFrame: 0.05))
        peekAnimation = SKAction.repeatForever(SKAction.animate(with: peekFrames, timePerFrame: 0.1))
        peekMustardAnimation = SKAction.repeatForever(SKAction.animate(with: peekMustardFrames, timePerFrame: 0.08))
        
        declareAllPoops()
        
        
        scoopActionLeft = SKAction.sequence([angleUp,moveOut, angleDown, moveBack])
        scoopActionLeftPart1 = SKAction.sequence([angleUp,moveOut])
        scoopActionLeftPart2 = SKAction.sequence([angleDown, moveBack])
        
        scoopActionRight = SKAction.sequence([angleDown,moveOutR, angleUp, moveBackR])
        scoopActionRightPart1 = SKAction.sequence([angleDown,moveOutR])
        scoopActionRightPart2 = SKAction.sequence([ angleUp, moveBackR])
        
        splashAction = SKAction.fadeOut(withDuration: 0.2)
        let pauseAction = SKAction.wait(forDuration: 1.0)
        let fadeAction = SKAction.fadeOut(withDuration: 0.5)
        let spinAction = SKAction.rotate(byAngle: 90, duration: 0.5)
        let groupAction = SKAction.group([spinAction, fadeAction])
        talkAction = SKAction.sequence([pauseAction, fadeAction])
        hidehelpAction = SKAction.sequence([pauseAction, groupAction])
        
        
        
        
        self.poopBar?.isHidden = true
        self.poopBar?.position = CGPoint(x: 0,y: -550)
        self.poopBar?.xScale = 0.1
        
        self.icon1 = self.childNode(withName: "//icon1") as? SKSpriteNode
        self.icon2 = self.childNode(withName: "//icon2") as? SKSpriteNode
        self.icon3 = self.childNode(withName: "//icon3") as? SKSpriteNode
        self.icon4 = self.childNode(withName: "//icon4") as? SKSpriteNode
        self.icon5 = self.childNode(withName: "//icon5") as? SKSpriteNode
        self.iconTalk = self.childNode(withName: "//icontalk") as? SKSpriteNode
        self.iconWords = self.childNode(withName: "//iconwords") as? SKLabelNode
        self.cat = self.childNode(withName: "//cat") as? SKSpriteNode
        
        //self.splat?.particleBirthRate = 0
        self.icon1?.alpha = 0
        self.icon2?.alpha = 0
        self.icon3?.alpha = 0
        self.icon4?.alpha = 0
        self.icon5?.alpha = 0
        self.iconTalk?.alpha = 0
        self.iconWords?.text = ""
        self.cat?.position = CGPoint(x: -600.0, y: 520)
        
        self.helpSprite = self.childNode(withName: "//help") as? SKSpriteNode
        
        self.messSplash = self.childNode(withName: "//mess") as? SKSpriteNode
        if let s = self.messSplash {
            s.alpha = 0.0
        }
        
        self.gameOver = self.childNode(withName: "//gameover") as? SKSpriteNode
        if let s = self.gameOver {
            s.alpha = 0.0
        }
        
        // Get label node from scene and store it for use later
        self.label = self.childNode(withName: "//helloLabel") as? SKLabelNode
        if let label = self.label {
            label.alpha = 0.0
            label.run(SKAction.fadeIn(withDuration: 2.0))
            
        }
        
        self.highLabel = self.childNode(withName: "//highLabel") as? SKLabelNode
        if let hlabel = self.highLabel {
            hlabel.text = "High: " + String(highscore)
            
            hlabel.alpha = 0.0
            hlabel.run(SKAction.fadeIn(withDuration: 2.5))
            
        }
        
        
        
        //
        //        // Create shape node to use during mouse interaction
        //        let w = (self.size.width + self.size.height) * 0.05
        //        self.spinnyNode = SKShapeNode.init(rectOf: CGSize.init(width: w, height: w), cornerRadius: w * 0.3)
        //
        //        if let spinnyNode = self.spinnyNode {
        //            spinnyNode.lineWidth = 2.5
        //
        //            spinnyNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat(Double.pi), duration: 1)))
        //            spinnyNode.run(SKAction.sequence([SKAction.wait(forDuration: 0.5),
        //                                              SKAction.fadeOut(withDuration: 0.5),
        //                                              SKAction.removeFromParent()]))
        //        }
    }
    
    
    func touchDown(atPoint pos : CGPoint) {
        
        
        if gameState == .Welcome
        {
            gameStateCounter = 0
            gameState = .ReadyToPlay
            return
        }
        
        if gameState == .ReadyToPlay
        {
            
            return
        }
        
        if gameState == .GameOver
        {
            
            return
        }
        
        
        if pos.x > 0
        {
            if ((rightScooper?.action(forKey: "scoopingRight")) == nil)
            {
                rightScooper!.run(scoopActionRight!, withKey: "scoopingRight")
            }
        }
        else
        {
            if ((leftScooper?.action(forKey: "scoopingLeft")) == nil)
            {
                leftScooper!.run(scoopActionLeft!, withKey: "scoopingLeft")
            }
        }
        
        
        
    }
    //
    //    func touchMoved(toPoint pos : CGPoint) {
    //        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
    //            n.position = pos
    //            n.strokeColor = SKColor.blue
    //            self.addChild(n)
    //        }
    //    }
    //
    //    func touchUp(atPoint pos : CGPoint) {
    //        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
    //            n.position = pos
    //            n.strokeColor = SKColor.red
    //            self.addChild(n)
    //        }
    //    }
    //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //  if let label = self.label {
        //      label.run(SKAction.init(named: "Pulse")!, withKey: "fadeInOut")
        //  }
        
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    //
    //    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    //        for t in touches { self.touchMoved(toPoint: t.location(in: self)) }
    //    }
    //
    //    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    //        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    //    }
    //
    //    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    //        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    //    }
    //
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        gameStateManager()
        
        if gameState != .Playing
        {
            return
        }
        
        if Int.random(in: 0...60) == 0
        {
            addNewPoop()
        }
        
        
        
        if pause
        {
            return
        }
        
        movePoops()
        
        
    }
}
